import robot
import time
import threading
import RPi.GPIO as IO

robot.forward(0.1)
robot.forward(0.1)
robot.forward(0.1)
robot.stop(1)
robot.forward(0.1)
robot.forward(0.1)
robot.forward(0.1)
robot.forward(0.1)
robot.forward(0.1)
robot.forward(0.1)
robot.forward(0.1)
robot.forward(0.1)
robot.forward(0.1)
robot.forward(0.1)
robot.forward(0.1)

IO.cleanup()