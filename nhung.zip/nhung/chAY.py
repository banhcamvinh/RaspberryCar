import robot

robot.forward(5)

#robot.right(5)

# robot.left(5)

